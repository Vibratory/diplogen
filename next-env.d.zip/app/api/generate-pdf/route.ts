import { type NextRequest, NextResponse } from "next/server"
import { jsPDF } from "jspdf"

interface DiplomaField {
  id: string
  type: "text" | "image" | "signature"
  title: string
  content: string
  x: number
  y: number
  width: number
  height: number
  fontSize: number
  fontFamily: string
  color: string
  fontWeight: string
  textAlign: "left" | "center" | "right"
}

interface GeneratePDFRequest {
  template: string
  fields: DiplomaField[]
  data?: Record<string, string>
  format?: "single" | "bulk"
  bulkData?: Record<string, string>[]
  headers?: string[]
  canvasDimensions?: { width: number; height: number }
  displayDimensions?: { width: number; height: number }
  dpi?: number
  includeTemplate?: boolean
}

export async function POST(request: NextRequest) {
  try {
    const {
      template,
      fields,
      data,
      format = "single",
      bulkData,
      headers,
      canvasDimensions = { width: 800, height: 600 },
      displayDimensions,
      dpi = 300,
      includeTemplate = true,
    }: GeneratePDFRequest = await request.json()

    if (!template || !fields) {
      return NextResponse.json({ error: "Template and fields are required" }, { status: 400 })
    }

    if (format === "bulk" && (!bulkData || bulkData.length === 0)) {
      return NextResponse.json({ error: "Bulk data is required for bulk generation" }, { status: 400 })
    }

    const pdfs = []
    const dataToProcess = format === "bulk" ? bulkData! : [data || {}]

    for (let i = 0; i < dataToProcess.length; i++) {
      const recordData = dataToProcess[i]

      // Convert px -> mm using provided DPI (mm per px = 25.4 / DPI). Default DPI=300 for print-accurate size.
      const MM_PER_PX = 25.4 / dpi
      const pdfWidth = canvasDimensions.width * MM_PER_PX // Convert px to mm
      const pdfHeight = canvasDimensions.height * MM_PER_PX // Convert px to mm

      // All field sizes/positions are stored relative to the full canvas in px
      // Convert px -> mm directly using DPI; no display scaling needed here
      const pxToMm = MM_PER_PX

      // Create new PDF document with proper dimensions
      const doc = new jsPDF({
        orientation: pdfWidth > pdfHeight ? "landscape" : "portrait",
        unit: "mm",
        format: [pdfWidth, pdfHeight],
      })

      // Set document properties
      doc.setProperties({
        title: "Diploma Certificate",
        subject: "Generated Diploma",
        author: "DiplomaGen",
        creator: "DiplomaGen App",
      })

      if (includeTemplate && template) {
        try {
          // Helper to resolve any URL/path to a data URL suitable for addImage
          const resolveToDataUrl = async (src: string): Promise<{ dataUrl: string; format: "PNG" | "JPEG" }> => {
            if (src.startsWith("data:image/")) {
              const isPng = src.toLowerCase().startsWith("data:image/png")
              return { dataUrl: src, format: isPng ? "PNG" : "JPEG" }
            }
            let url = src
            if (src.startsWith("/")) {
              // Build absolute URL for local public assets
              const origin = request.nextUrl.origin
              url = new URL(src, origin).toString()
            }
            const res = await fetch(url)
            if (!res.ok) throw new Error(`Failed to fetch image: ${res.status}`)
            const buf = Buffer.from(await res.arrayBuffer())
            const contentType = res.headers.get("content-type") || "image/png"
            const base64 = buf.toString("base64")
            const dataUrl = `data:${contentType};base64,${base64}`
            const isPng = contentType.toLowerCase().includes("png")
            return { dataUrl, format: isPng ? "PNG" : "JPEG" }
          }

          const { dataUrl, format } = await resolveToDataUrl(template)
          doc.addImage(dataUrl, format, 0, 0, pdfWidth, pdfHeight, undefined, "FAST")
        } catch (error) {
          console.warn(" Could not load template background:", error)
          // Fallback to white background with border
          doc.setFillColor(255, 255, 255)
          doc.rect(0, 0, pdfWidth, pdfHeight, "F")
          doc.setDrawColor(0, 0, 0)
          doc.setLineWidth(1)
          doc.rect(2, 2, pdfWidth - 4, pdfHeight - 4)
        }
      }

      // Process each field
      for (const field of fields) {
        if (field.type === "text") {
          // Base position (top-left of the text box) derived from percentage
          const leftMm = (field.x / 100) * pdfWidth
          const topMm = (field.y / 100) * pdfHeight

          // Map font families to jsPDF fonts
          // Map many common font family names to jsPDF base fonts
          const ff = (field.fontFamily || "").toLowerCase()
          const serifGroup = [
            "serif",
            "times",
            "times new roman",
            "georgia",
            "garamond",
            "palatino",
            "palatino linotype",
            "cambria",
            "noto serif",
          ]
          const monoGroup = [
            "monospace",
            "mono",
            "courier",
            "courier new",
            "lucida console",
            "fira code",
            "jetbrains mono",
          ]
          const sansGroup = [
            "sans",
            "sans-serif",
            "arial",
            "helvetica",
            "verdana",
            "tahoma",
            "trebuchet ms",
            "segoe ui",
            "calibri",
            "noto sans",
          ]
          const fontFamily = serifGroup.includes(ff)
            ? "times"
            : monoGroup.includes(ff)
            ? "courier"
            : "helvetica" // default for sans and unknown families

          const fontStyle = field.fontWeight === "bold" ? "bold" : "normal"

          // Use font size in canvas px, convert directly to points using DPI (pt/px = 72/DPI)
          const fontSizePx = field.fontSize || 16
          doc.setFont(fontFamily, fontStyle)
          doc.setFontSize(fontSizePx * (72 / dpi))

          // Text color
          const color = field.color || "#000000"
          const r = parseInt(color.slice(1, 3), 16)
          const g = parseInt(color.slice(3, 5), 16)
          const b = parseInt(color.slice(5, 7), 16)
          doc.setTextColor(r, g, b)

          // Resolve content from bulk/single data when available
          let content = field.content
          if (recordData && field.title) {
            const fieldKey = Object.keys(recordData).find(
              (key) =>
                key.toLowerCase() === field.title.toLowerCase() ||
                key.toLowerCase().includes(field.title.toLowerCase()) ||
                field.title.toLowerCase().includes(key.toLowerCase()) ||
                key.toLowerCase().replace(/[^a-z0-9]/g, "") ===
                  field.title.toLowerCase().replace(/[^a-z0-9]/g, "")
            )
            content = fieldKey ? String(recordData[fieldKey]) : field.content
          }

          const align: "left" | "center" | "right" =
            field.textAlign === "center" ? "center" :
            field.textAlign === "right" ? "right" : "left"

          // Compute box width/height in mm using scale from display -> canvas
          const boxWidthMm = (field.width || 0) * pxToMm
          const boxHeightMm = (field.height || 0) * pxToMm

          // Horizontal anchor: x corresponds to the left edge of the text box in the editor
          let xMm = leftMm
          if (align === "center") xMm = leftMm + boxWidthMm / 2
          else if (align === "right") xMm = leftMm + boxWidthMm

          // Vertical anchor: center text within the box, approximating text height by font size
          const fontHeightMm = fontSizePx * MM_PER_PX
          let yMm = topMm
          if (boxHeightMm > 0) {
            yMm = topMm + Math.max(0, (boxHeightMm - fontHeightMm) / 2)
          }

          doc.text(content, xMm, yMm, {
            align,
            baseline: "top",
          })
        } else if (field.type === "image" && field.content) {
          try {
            const resolveToDataUrl = async (src: string): Promise<{ dataUrl: string; format: "PNG" | "JPEG" }> => {
              if (src.startsWith("data:image/")) {
                const isPng = src.toLowerCase().startsWith("data:image/png")
                return { dataUrl: src, format: isPng ? "PNG" : "JPEG" }
              }
              let url = src
              if (src.startsWith("/")) {
                const origin = request.nextUrl.origin
                url = new URL(src, origin).toString()
              }
              const res = await fetch(url)
              if (!res.ok) throw new Error(`Failed to fetch image: ${res.status}`)
              const buf = Buffer.from(await res.arrayBuffer())
              const contentType = res.headers.get("content-type") || "image/png"
              const base64 = buf.toString("base64")
              const dataUrl = `data:${contentType};base64,${base64}`
              const isPng = contentType.toLowerCase().includes("png")
              return { dataUrl, format: isPng ? "PNG" : "JPEG" }
            }
            const { dataUrl, format } = await resolveToDataUrl(field.content)
            const leftMm = (field.x / 100) * pdfWidth
            const topMm = (field.y / 100) * pdfHeight
            const wMm = (field.width || 0) * pxToMm
            const hMm = (field.height || 0) * pxToMm
            doc.addImage(dataUrl, format, leftMm, topMm, wMm, hMm, undefined, "FAST")
          } catch (e) {
            console.warn(" Failed to add image field:", e)
          }
        }
      }

      // Convert to base64
      const pdfBase64 = doc.output("datauristring")

      let filename = "diploma.pdf"
      if (format === "bulk" && recordData) {
        const nameField = fields.find(
          (f) =>
            f.title.toLowerCase().includes("name") ||
            f.title.toLowerCase().includes("student") ||
            f.title.toLowerCase().includes("recipient"),
        )
        let nameValue = null
        if (nameField) {
          const fieldKey = Object.keys(recordData).find(
            (key) =>
              key.toLowerCase() === nameField.title.toLowerCase() ||
              key.toLowerCase().includes(nameField.title.toLowerCase()) ||
              nameField.title.toLowerCase().includes(key.toLowerCase()),
          )
          nameValue = fieldKey ? String(recordData[fieldKey]).replace(/[^a-zA-Z0-9]/g, "-") : null
        }
        filename = `diploma-${nameValue || `record-${i + 1}`}.pdf`
      }

      pdfs.push({
        filename,
        data: pdfBase64,
        size: { width: pdfWidth, height: pdfHeight },
      })
    }

    if (format === "single") {
      return NextResponse.json({
        success: true,
        pdf: pdfs[0],
        message: "PDF generated successfully",
      })
    } else {
      return NextResponse.json({
        success: true,
        pdfs,
        count: pdfs.length,
        message: `${pdfs.length} PDFs generated successfully`,
      })
    }
  } catch (error) {
    console.error("PDF generation error:", error)
    return NextResponse.json({ error: "PDF generation failed" }, { status: 500 })
  }
}
