import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { prisma } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { userId } = await auth()
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    const admin = await prisma.admin.findUnique({
      where: { id: userId }
    })

    if (!admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const body = await request.json()
    const { templateId, approved } = body

    if (!templateId || typeof approved !== 'boolean') {
      return NextResponse.json({ error: 'Template ID and approval status are required' }, { status: 400 })
    }

    const template = await prisma.template.update({
      where: { id: templateId },
      data: {
        approved,
        approvedBy: approved ? userId : null,
        approvedAt: approved ? new Date() : null
      }
    })

    // Update admin stats
    if (approved) {
      await prisma.admin.update({
        where: { id: userId },
        data: { approvedTemplates: { increment: 1 } }
      })

      // Update global statistics
      await prisma.statistics.upsert({
        where: { id: 'global' },
        update: {
          approvedTemplates: { increment: 1 },
          pendingTemplates: { decrement: 1 }
        },
        create: {
          id: 'global',
          approvedTemplates: 1,
          pendingTemplates: 0
        }
      })
    }

    return NextResponse.json({ template })
  } catch (error) {
    console.error('Error approving template:', error)
    return NextResponse.json({ error: 'Failed to approve template' }, { status: 500 })
  }
}