import { DiplomaEditor } from "@/components/diploma-editor"

export default function EditorPage() {
  return (
    <div className="min-h-screen bg-background">
      <DiplomaEditor />
    </div>
  )
}
